﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Schema;

namespace FoodOrder.Models
{
    public class OrderItem
    {
        public OrderItem(int itemId,decimal ui,int q,decimal t) 
        {
            ItemId = itemId;
            UnitPrice = ui;
            Quantity = q;
            Total = t;
        }
        public int Id { get; set; }
        public int ItemId { get; set; }
        public decimal UnitPrice { get; set; }
        public int Quantity { get; set; }
        public decimal Total { get; set; }
        public string OrderId { get; set; }
        public virtual Order Order { get; set; }
    }
}
